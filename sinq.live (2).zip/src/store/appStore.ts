import { create } from 'zustand';

interface UserProfile {
  uid: string;
  username: string;
  displayName: string;
  photoURL: string;
  bio: string;
  followersCount: number;
  followingCount: number;
  isLive: boolean;
}

interface ChatMessage {
  id: string;
  u: string; // username
  m: string; // message
  t: string; // type (m/f/system)
  timestamp: number;
}

interface AppState {
  userProfile: UserProfile | null;
  setUserProfile: (profile: UserProfile | null) => void;
  activeLiveId: string | null;
  setActiveLiveId: (id: string | null) => void;
  liveViews: number;
  setLiveViews: (views: number) => void;
  chat: ChatMessage[];
  addChatMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  clearChat: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  userProfile: null,
  setUserProfile: (userProfile) => set({ userProfile }),
  activeLiveId: null,
  setActiveLiveId: (activeLiveId) => set({ activeLiveId }),
  liveViews: 0,
  setLiveViews: (liveViews) => set({ liveViews }),
  chat: [],
  addChatMessage: (message) => set((state) => {
    // Filtro simples de palavras proibidas
    const blockedWords = ['spam', 'badword1', 'badword2'];
    const filteredMessage = message.m.split(' ').map(word => 
      blockedWords.includes(word.toLowerCase()) ? '***' : word
    ).join(' ');

    return { 
      chat: [
        ...state.chat.slice(-15), 
        { ...message, m: filteredMessage, id: Math.random().toString(36).substr(2, 9), timestamp: Date.now() }
      ] 
    };
  }),
  clearChat: () => set({ chat: [] }),
}));
