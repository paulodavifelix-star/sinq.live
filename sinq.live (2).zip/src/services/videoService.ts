import { db, storage, collection, doc, addDoc, updateDoc, increment, serverTimestamp, ref, uploadBytes, getDownloadURL, query, orderBy, limit, onSnapshot } from './firebase';

export const uploadVideo = async (file: File, userId: string) => {
  const videoRef = ref(storage, `videos/${Date.now()}_${file.name}`);
  await uploadBytes(videoRef, file);
  const url = await getDownloadURL(videoRef);
  
  const docRef = await addDoc(collection(db, 'videos'), {
    url,
    userId,
    createdAt: serverTimestamp(),
    views: 0,
    likes: 0
  });
  
  return docRef.id;
};

export const incrementViews = async (videoId: string) => {
  const videoRef = doc(db, 'videos', videoId);
  await updateDoc(videoRef, {
    views: increment(1)
  });
};

export const subscribeToVideos = (callback: (videos: any[]) => void) => {
  const q = query(collection(db, 'videos'), orderBy('createdAt', 'desc'), limit(20));
  return onSnapshot(q, (snapshot) => {
    const videos = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(videos);
  });
};
