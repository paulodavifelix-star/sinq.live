import { useEffect, useState } from 'react';
import { subscribeToVideos } from '../services/videoService';

export const useFeed = () => {
  const [videos, setVideos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = subscribeToVideos((data) => {
      setVideos(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return { videos, loading };
};
