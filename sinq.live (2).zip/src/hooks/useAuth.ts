import { useEffect, useState, useCallback } from 'react';
import { auth, signInAnonymously, onAuthStateChanged, db, doc, getDoc, setDoc, type User } from '../services/firebase';
import { useAppStore } from '../store/appStore';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const setUserProfile = useAppStore(state => state.setUserProfile);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        // Sync with Firestore profile
        const userDoc = await getDoc(doc(db, 'users', u.uid));
        if (userDoc.exists()) {
          const data = userDoc.data();
          setUserProfile({
            uid: u.uid,
            username: data.username || 'user_' + u.uid.slice(0, 5),
            displayName: data.displayName || 'Anonymous',
            photoURL: data.photoURL || `https://picsum.photos/seed/${u.uid}/200`,
            bio: data.bio || '',
            followersCount: data.followersCount || 0,
            followingCount: data.followingCount || 0,
            isLive: data.isLive || false,
          });
        } else {
          // Create initial profile
          const initialProfile = {
            username: 'user_' + u.uid.slice(0, 5),
            displayName: 'Anonymous',
            photoURL: `https://picsum.photos/seed/${u.uid}/200`,
            bio: 'New streamer on sinq.live!',
            followersCount: 0,
            followingCount: 0,
            isLive: false,
            createdAt: new Date().toISOString()
          };
          await setDoc(doc(db, 'users', u.uid), initialProfile);
          setUserProfile({ uid: u.uid, ...initialProfile });
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [setUserProfile]);

  const login = useCallback(async () => {
    setLoading(true);
    try {
      await signInAnonymously(auth);
    } catch (error) {
      console.error('Login error:', error);
      throw error; // Relançar o erro para ser tratado pelo componente
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await auth.signOut();
    } catch (error) {
      console.error('Logout error:', error);
    }
  }, []);

  return { user, loading, login, logout };
};
