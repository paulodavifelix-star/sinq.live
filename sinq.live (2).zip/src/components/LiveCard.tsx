import React from 'react';
import { motion } from 'motion/react';
import { Users, Play } from 'lucide-react';
import { useAppStore } from '../store/appStore';

interface LiveCardProps {
  live: {
    id: string;
    title: string;
    streamer: string;
    viewers: number;
    thumbnail: string;
    category: string;
    photo?: string;
  };
  onClick?: () => void;
}

export const LiveCard: React.FC<LiveCardProps> = ({ live, onClick }) => {
  const { liveViews } = useAppStore();
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -10 }}
      onClick={onClick}
      className="glass-panel overflow-hidden group cursor-pointer border-white/5 hover:border-neon-purple/30 transition-all"
    >
      <div className="relative aspect-[4/5]">
        <img src={live.thumbnail} alt={live.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
        
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          <div className="bg-neon-red px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest shadow-lg animate-soft-pulse">Live</div>
          <div className="bg-black/60 backdrop-blur-md px-2 py-1 rounded-lg text-[10px] font-bold text-neon-blue border border-white/10 uppercase tracking-widest">{live.category}</div>
        </div>

        <div className="absolute bottom-4 left-4 right-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex items-center gap-1 bg-black/40 backdrop-blur-md px-2 py-1 rounded-full text-[10px] font-bold">
              <Users className="w-3 h-3 text-neon-blue" />
              {(live.viewers + liveViews).toLocaleString()}
            </div>
          </div>
          <h3 className="text-lg font-black leading-tight group-hover:neon-text-purple transition-colors line-clamp-2">{live.title}</h3>
          <p className="text-xs text-gray-400 font-bold mt-1">@{live.streamer}</p>
        </div>

        <div className="absolute inset-0 bg-neon-purple/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <motion.div 
            whileHover={{ scale: 1.1 }}
            className="w-16 h-16 bg-neon-purple rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(176,38,255,0.8)]"
          >
            <Play className="w-8 h-8 fill-white ml-1" />
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};
