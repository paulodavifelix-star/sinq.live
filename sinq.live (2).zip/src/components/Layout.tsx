import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Search, PlusSquare, User, Radio, Bell, Menu, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';
import { useAppStore } from '../store/appStore';
import { motion, AnimatePresence } from 'motion/react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const userProfile = useAppStore(state => state.userProfile);

  const navItems = [
    { icon: Home, path: '/', label: 'Início' },
    { icon: Search, path: '/search', label: 'Explorar' },
    { icon: Radio, path: '/live', label: 'Ao Vivo', activeColor: 'text-neon-red' },
    { icon: PlusSquare, path: '/upload', label: 'Enviar' },
    { icon: User, path: `/profile/${userProfile?.username || 'me'}`, label: 'Perfil' },
  ];

  return (
    <div className="flex h-screen bg-black text-white overflow-hidden font-sans">
      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 relative">
        {/* Top Bar */}
        <header className="h-16 flex items-center justify-between px-6 border-b border-white/5 bg-black/50 backdrop-blur-xl z-50">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-neon-purple to-neon-pink rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(176,38,255,0.5)]">
              <Radio className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-black tracking-tighter neon-text-purple">sinq</span>
          </Link>
          
          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-400 hover:text-white transition-colors">
              <Bell className="w-6 h-6" />
            </button>
            {userProfile && (
              <Link to={`/profile/${userProfile.username}`} className="w-8 h-8 rounded-full overflow-hidden border border-neon-purple/50">
                <img src={userProfile.photoURL} alt="Profile" className="w-full h-full object-cover" />
              </Link>
            )}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto scrollbar-hide relative pb-20">
          {children}
        </main>

        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 left-0 right-0 h-20 bg-black/80 backdrop-blur-2xl border-t border-white/5 flex items-center justify-around px-4 z-50">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex flex-col items-center gap-1 transition-all duration-300",
                  isActive ? (item.activeColor || "text-neon-purple scale-110") : "text-gray-500 hover:text-gray-300"
                )}
              >
                <Icon className={cn("w-6 h-6", isActive && "drop-shadow-[0_0_8px_currentColor] fill-current")} />
                <span className="text-[9px] font-black uppercase tracking-widest">{item.label}</span>
                {isActive && (
                  <motion.div 
                    layoutId="activeNavMobile"
                    className="w-1 h-1 bg-neon-purple rounded-full mt-1 shadow-[0_0_10px_rgba(176,38,255,1)]"
                  />
                )}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

export default Layout;
