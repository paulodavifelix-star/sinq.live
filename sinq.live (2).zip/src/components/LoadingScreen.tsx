import React from 'react';
import { Radio } from 'lucide-react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-[100]">
      <div className="relative">
        <div className="w-24 h-24 bg-gradient-to-br from-neon-purple to-neon-pink rounded-3xl flex items-center justify-center shadow-[0_0_50px_rgba(176,38,255,0.4)] animate-pulse">
          <Radio className="w-12 h-12 text-white" />
        </div>
        <div className="absolute -inset-4 border-2 border-neon-purple/20 rounded-[2.5rem] animate-spin-slow" />
      </div>
      <div className="mt-12 text-center">
        <h2 className="text-2xl font-black tracking-tighter neon-text-purple mb-2">sinq.live</h2>
        <div className="flex gap-1 justify-center">
          <div className="w-1.5 h-1.5 bg-neon-purple rounded-full animate-bounce [animation-delay:-0.3s]" />
          <div className="w-1.5 h-1.5 bg-neon-purple rounded-full animate-bounce [animation-delay:-0.15s]" />
          <div className="w-1.5 h-1.5 bg-neon-purple rounded-full animate-bounce" />
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;
