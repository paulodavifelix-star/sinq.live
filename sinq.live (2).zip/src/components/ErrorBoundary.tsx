import React from 'react';
import { AlertCircle, RefreshCcw, Home } from 'lucide-react';
import { NeonButton } from './NeonButton';

interface Props {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    // @ts-ignore
    this.state = {
      hasError: false,
      error: null
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  private handleReset = () => {
    // @ts-ignore
    this.setState({ hasError: false, error: null });
    window.location.href = '/';
  };

  public render() {
    // @ts-ignore
    const { hasError, error } = this.state;
    // @ts-ignore
    const { children, fallback } = this.props;

    if (hasError) {
      if (fallback) {
        return fallback;
      }

      return (
        <div className="min-h-screen bg-black flex items-center justify-center p-6 text-center">
          <div className="max-w-md w-full space-y-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-neon-red/10 rounded-3xl border border-neon-red/30 shadow-[0_0_30px_rgba(255,0,85,0.2)] mb-4">
              <AlertCircle className="w-10 h-10 text-neon-red" />
            </div>
            
            <div className="space-y-4">
              <h1 className="text-3xl font-black tracking-tighter uppercase">Something went wrong</h1>
              <p className="text-gray-400 font-medium">
                We encountered an unexpected error. Don't worry, your neon world is still here.
              </p>
              {error && (
                <div className="bg-white/5 border border-white/10 p-4 rounded-xl text-left overflow-hidden">
                  <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mb-2">Error Details</p>
                  <code className="text-xs text-neon-red font-mono break-all line-clamp-3">
                    {error.message}
                  </code>
                </div>
              )}
            </div>

            <div className="flex flex-col gap-3 pt-4">
              <NeonButton onClick={this.handleReset} className="w-full flex items-center justify-center gap-2">
                <RefreshCcw className="w-5 h-5" />
                Try Again
              </NeonButton>
              <button 
                onClick={() => window.location.href = '/'}
                className="w-full py-4 rounded-full border border-white/10 font-bold text-sm hover:bg-white/5 transition-all text-gray-300 flex items-center justify-center gap-2"
              >
                <Home className="w-5 h-5" />
                Back to Home
              </button>
            </div>
          </div>
        </div>
      );
    }

    return children;
  }
}

export default ErrorBoundary;
