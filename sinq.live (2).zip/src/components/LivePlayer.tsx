import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, MessageCircle, Share2, Users, Radio, X, Send, Zap } from 'lucide-react';
import { useAppStore } from '../store/appStore';
import { NeonButton } from './NeonButton';
import { cn } from '../lib/utils';

interface LivePlayerProps {
  streamId: string;
  streamerName: string;
  streamerPhoto: string;
  viewerCount: number;
  onClose?: () => void;
}

export const LivePlayer: React.FC<LivePlayerProps> = ({
  streamId,
  streamerName,
  streamerPhoto,
  viewerCount,
  onClose
}) => {
  const [comment, setComment] = useState('');
  const { chat, addChatMessage, liveViews } = useAppStore();
  const [isLiked, setIsLiked] = useState(false);
  const [showHeart, setShowHeart] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);
  const emojis = ['🔥', '✨', '💜', '😲', '🚀', '👏', '😂', '😍'];

  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [chat]);

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) return;
    addChatMessage({ u: 'Você', m: comment, t: 'm' });
    setComment('');
  };

  const addEmoji = (emoji: string) => {
    setComment(prev => prev + emoji);
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    if (!isLiked) {
      setShowHeart(true);
      setTimeout(() => setShowHeart(false), 1000);
    }
  };

  return (
    <div className="relative h-dvh w-full bg-black overflow-hidden flex flex-col font-sans">
      {/* Video Background (Placeholder) */}
      <div className="absolute inset-0 z-0">
        <motion.img 
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.6 }}
          src={`https://picsum.photos/seed/${streamId}/1080/1920`} 
          alt="Live Stream" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/60" />
      </div>

      {/* Top Overlay */}
      <div className="relative z-10 p-6 flex items-center justify-between">
        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="flex items-center gap-3 bg-black/40 backdrop-blur-2xl p-1.5 pr-5 rounded-full border border-white/10 shadow-2xl"
        >
          <div className="relative">
            <img src={streamerPhoto} alt={streamerName} className="w-11 h-11 rounded-full border-2 border-neon-purple object-cover" />
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-neon-purple rounded-full border-2 border-black flex items-center justify-center">
              <Zap className="w-2 h-2 text-white fill-current" />
            </div>
          </div>
          <div>
            <h3 className="text-sm font-black leading-tight tracking-tight">{streamerName}</h3>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 bg-neon-red rounded-full animate-soft-pulse shadow-[0_0_8px_rgba(255,0,85,0.8)]" />
              <span className="text-[9px] text-gray-300 font-black uppercase tracking-[0.1em]">Live Now</span>
            </div>
          </div>
          <NeonButton size="sm" className="ml-3 h-8 px-4 text-[10px]">Seguir</NeonButton>
        </motion.div>

        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="flex items-center gap-3"
        >
          <div className="bg-black/40 backdrop-blur-2xl px-4 py-2 rounded-full border border-white/10 flex items-center gap-2.5 shadow-2xl">
            <Users className="w-4 h-4 text-neon-blue" />
            <span className="text-xs font-black tracking-widest">{(viewerCount + liveViews).toLocaleString()}</span>
          </div>
          <button 
            onClick={onClose} 
            className="p-2.5 bg-black/40 backdrop-blur-2xl rounded-full border border-white/10 hover:bg-neon-red/20 hover:border-neon-red/40 transition-all group"
          >
            <X className="w-5 h-5 group-hover:text-neon-red transition-colors" />
          </button>
        </motion.div>
      </div>

      {/* Floating Heart Animation */}
      <AnimatePresence>
        {showHeart && (
          <motion.div
            initial={{ opacity: 0, y: 0, scale: 0.5 }}
            animate={{ opacity: 1, y: -200, scale: 1.5, x: [0, 20, -20, 0] }}
            exit={{ opacity: 0 }}
            className="absolute bottom-32 right-10 z-50 text-neon-red"
          >
            <Heart className="w-12 h-12 fill-current shadow-neon-red" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Area */}
      <div className="flex-1 relative z-10 flex flex-col justify-end p-4 gap-4 overflow-hidden">
        <div 
          ref={chatRef}
          className="flex flex-col gap-2 max-h-[40%] overflow-y-auto scrollbar-hide mask-gradient-top transition-all duration-500"
        >
          <AnimatePresence initial={false}>
            {chat.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, x: -30, scale: 0.9 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                className="flex items-start gap-2 group"
              >
                <div className="bg-black/30 backdrop-blur-2xl px-3 py-2 rounded-[1rem] rounded-tl-none border border-white/10 max-w-[90%] shadow-xl hover:bg-black/40 transition-colors">
                  <div className="flex items-center justify-between gap-3 mb-0.5">
                    <span className={cn(
                      "text-[9px] font-black uppercase tracking-[0.2em]",
                      msg.t === 'f' ? "text-neon-pink" : "text-neon-blue"
                    )}>
                      {msg.u}
                    </span>
                    <span className="text-[8px] text-gray-500 font-bold">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-gray-100 leading-relaxed font-medium">{msg.m}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Interaction Bar */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="flex flex-col gap-2 bg-black/20 p-3 rounded-2xl backdrop-blur-xl border border-white/5"
        >
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {emojis.map(emoji => (
              <button key={emoji} onClick={() => addEmoji(emoji)} className="text-lg hover:scale-125 transition-transform p-1">
                {emoji}
              </button>
            ))}
          </div>
          
          <div className="flex items-center gap-2">
            <form onSubmit={handleSendComment} className="flex-1 relative group">
              <input 
                type="text"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Participe..."
                className="w-full bg-white/5 border border-white/10 rounded-full py-2.5 px-4 text-xs font-medium focus:outline-none focus:border-neon-purple/50 transition-all placeholder:text-gray-500"
              />
              <button 
                type="submit" 
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-neon-purple rounded-full text-white hover:scale-110 active:scale-95 transition-all"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

            <button 
              onClick={handleLike}
              className={cn(
                "p-2.5 rounded-full border transition-all duration-300",
                isLiked 
                  ? "bg-neon-red border-neon-red text-white shadow-[0_0_10px_rgba(255,0,85,0.4)]" 
                  : "bg-white/5 border-white/10 text-white hover:bg-white/10"
              )}
            >
              <Heart className={cn("w-4 h-4 transition-transform", isLiked && "fill-current scale-110")} />
            </button>
            <button className="p-2.5 rounded-full bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-all">
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
