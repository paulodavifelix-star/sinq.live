import React from 'react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface NeonButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'purple' | 'blue' | 'red' | 'cyan';
  size?: 'sm' | 'md' | 'lg';
  glow?: boolean;
}

export const NeonButton: React.FC<NeonButtonProps> = ({ 
  children, 
  className, 
  variant = 'purple', 
  size = 'md',
  glow = true,
  ...props 
}) => {
  const variants = {
    purple: 'bg-neon-purple shadow-[0_0_15px_rgba(176,38,255,0.4)] hover:shadow-[0_0_30px_rgba(176,38,255,0.6)]',
    blue: 'bg-neon-blue shadow-[0_0_15px_rgba(0,210,255,0.4)] hover:shadow-[0_0_30px_rgba(0,210,255,0.6)]',
    red: 'bg-neon-red shadow-[0_0_15px_rgba(255,0,85,0.4)] hover:shadow-[0_0_30px_rgba(255,0,85,0.6)]',
    cyan: 'bg-neon-cyan shadow-[0_0_15px_rgba(0,255,255,0.4)] hover:shadow-[0_0_30px_rgba(0,255,255,0.6)]',
  };

  const sizes = {
    sm: 'px-5 py-2 text-[10px] uppercase tracking-[0.2em]',
    md: 'px-8 py-3 text-xs uppercase tracking-[0.2em]',
    lg: 'px-10 py-4 text-sm uppercase tracking-[0.2em]',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={cn(
        'relative font-black rounded-full transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-white overflow-hidden group',
        variants[variant],
        sizes[size],
        glow && 'animate-neon-pulse',
        className
      )}
      {...props}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover:animate-shimmer" />
      <span className="relative z-10 flex items-center justify-center gap-2">{children}</span>
    </motion.button>
  );
};
