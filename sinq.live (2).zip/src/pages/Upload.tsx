import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload as UploadIcon, X, CheckCircle, AlertCircle, Loader2, Image as ImageIcon, Send } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { db, collection, addDoc, serverTimestamp, storage, ref, uploadBytes, getDownloadURL, handleFirestoreError, OperationType } from '../services/firebase';
import { useAppStore } from '../store/appStore';
import { NeonButton } from '../components/NeonButton';

export const Upload: React.FC = () => {
  const [content, setContent] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const { user } = useAuth();
  const userProfile = useAppStore(state => state.userProfile);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Image size must be less than 5MB');
        return;
      }
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
      setError(null);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !image) return;
    if (!user || !userProfile) return;

    setUploading(true);
    setError(null);

    try {
      let imageUrl = '';
      if (image) {
        const storageRef = ref(storage, `posts/${user.uid}/${Date.now()}_${image.name}`);
        const snapshot = await uploadBytes(storageRef, image);
        imageUrl = await getDownloadURL(snapshot.ref);
      }

      await addDoc(collection(db, 'posts'), {
        userId: user.uid,
        username: userProfile.username,
        userPhoto: userProfile.photoURL,
        content: content.trim(),
        image: imageUrl,
        likesCount: 0,
        commentsCount: 0,
        createdAt: serverTimestamp(),
      });

      setSuccess(true);
      setTimeout(() => navigate('/'), 2000);
    } catch (err: any) {
      handleFirestoreError(err, OperationType.CREATE, 'posts');
      setError('Failed to share your post. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-8">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-12 h-12 bg-neon-purple/20 rounded-2xl flex items-center justify-center border border-neon-purple/30">
          <UploadIcon className="w-6 h-6 text-neon-purple" />
        </div>
        <div>
          <h1 className="text-2xl font-black tracking-tight uppercase">Share Something</h1>
          <p className="text-xs text-gray-500 font-bold tracking-widest uppercase">Post to the sinq.live community</p>
        </div>
      </div>

      {success ? (
        <div className="glass-panel p-12 text-center space-y-4 animate-in fade-in zoom-in duration-500">
          <div className="w-20 h-20 bg-neon-blue/20 rounded-full flex items-center justify-center mx-auto border border-neon-blue/30 shadow-[0_0_30px_rgba(0,210,255,0.2)]">
            <CheckCircle className="w-10 h-10 text-neon-blue" />
          </div>
          <h2 className="text-2xl font-black tracking-tight uppercase">Shared Successfully!</h2>
          <p className="text-gray-400 font-medium">Redirecting you to the feed...</p>
        </div>
      ) : (
        <form onSubmit={handleUpload} className="space-y-6">
          <div className="glass-panel p-6 space-y-6">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What's happening in your neon world?"
              className="w-full bg-transparent border-none focus:ring-0 text-lg text-gray-100 placeholder:text-gray-600 resize-none min-h-[120px]"
            />

            {preview ? (
              <div className="relative rounded-2xl overflow-hidden border border-white/10 aspect-video">
                <img src={preview} alt="Preview" className="w-full h-full object-cover" />
                <button 
                  type="button"
                  onClick={() => { setImage(null); setPreview(null); }}
                  className="absolute top-4 right-4 p-2 bg-black/60 backdrop-blur-md rounded-full text-white hover:bg-neon-red transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full aspect-video border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center gap-3 text-gray-500 hover:border-neon-purple/50 hover:text-neon-purple hover:bg-neon-purple/5 transition-all group"
              >
                <div className="p-4 bg-white/5 rounded-2xl group-hover:bg-neon-purple/10 transition-colors">
                  <ImageIcon className="w-8 h-8" />
                </div>
                <span className="text-xs font-bold uppercase tracking-widest">Add an image (Optional)</span>
              </button>
            )}

            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
          </div>

          {error && (
            <div className="bg-neon-red/10 border border-neon-red/20 p-4 rounded-xl flex items-center gap-3 text-neon-red text-xs font-bold">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          <div className="flex justify-end gap-4">
            <button 
              type="button"
              onClick={() => navigate('/')}
              className="px-8 py-3.5 rounded-full border border-white/10 font-bold text-sm hover:bg-white/5 transition-all text-gray-500"
            >
              Cancel
            </button>
            <NeonButton 
              type="submit" 
              disabled={uploading || (!content.trim() && !image)}
              className="flex items-center gap-2 min-w-[160px] justify-center"
            >
              {uploading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Sharing...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  Post Now
                </>
              )}
            </NeonButton>
          </div>
        </form>
      )}
    </div>
  );
};
