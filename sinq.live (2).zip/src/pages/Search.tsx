import React, { useState, useEffect } from 'react';
import { Search as SearchIcon, X, TrendingUp, Users, Radio, Hash, Sparkles } from 'lucide-react';
import { collection, db, getDocs, query, where, limit, handleFirestoreError, OperationType } from '../services/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { LiveCard } from '../components/LiveCard';
import { LivePlayer } from '../components/LivePlayer';

const TRENDING_TAGS = ['gaming', 'valorant', 'música', 'tech', 'arte', 'stream', 'live', 'react', 'javascript', 'noite', 'anime', 'fitness'];
const CATEGORIES = [
  { name: 'Gaming', emoji: '🎮', grad: 'from-purple-600 to-purple-900', color: 'neon-purple' },
  { name: 'Música', emoji: '🎵', grad: 'from-blue-600 to-blue-900', color: 'neon-blue' },
  { name: 'Arte', emoji: '🎨', grad: 'from-red-500 to-red-900', color: 'neon-red' },
  { name: 'Tech', emoji: '💻', grad: 'from-cyan-600 to-cyan-900', color: 'neon-cyan' },
  { name: 'Lifestyle', emoji: '✨', grad: 'from-pink-600 to-pink-900', color: 'neon-pink' },
  { name: 'Esportes', emoji: '⚽', grad: 'from-green-600 to-green-900', color: 'neon-green' },
  { name: 'Educação', emoji: '📚', grad: 'from-yellow-600 to-yellow-900', color: 'neon-yellow' },
  { name: 'Entretenimento', emoji: '🎬', grad: 'from-orange-600 to-orange-900', color: 'neon-orange' },
];

export const Search: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [allLives, setAllLives] = useState<any[]>([]);
  const [searchResults, setSearchResults] = useState<{ lives: any[], creators: any[] }>({ lives: [], creators: [] });
  const [isSearching, setIsSearching] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeStream, setActiveStream] = useState<any>(null);

  useEffect(() => {
    // Mock lives for now, in a real app these would come from a 'lives' collection
    const mockLives = [
      { id: 'l1', title: 'Late Night Coding', streamer: 'dev_davi', viewers: 1240, thumbnail: 'https://picsum.photos/seed/code/600/800', category: 'Gaming', photo: 'https://picsum.photos/seed/p1/100' },
      { id: 'l2', title: 'Neon Art Session', streamer: 'art_vibe', viewers: 850, thumbnail: 'https://picsum.photos/seed/art/600/800', category: 'Arte', photo: 'https://picsum.photos/seed/p2/100' },
      { id: 'l3', title: 'Gaming with Subs', streamer: 'pro_gamer', viewers: 3200, thumbnail: 'https://picsum.photos/seed/game/600/800', category: 'Gaming', photo: 'https://picsum.photos/seed/p3/100' },
      { id: 'l4', title: 'Cyberpunk Beats', streamer: 'dj_neon', viewers: 1500, thumbnail: 'https://picsum.photos/seed/music/600/800', category: 'Música', photo: 'https://picsum.photos/seed/p4/100' },
    ];
    setAllLives(mockLives);
  }, []);

  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      setIsSearching(true);
      try {
        const q = searchTerm.toLowerCase();
        
        // Filter lives locally (mock)
        const filteredLives = allLives.filter(l =>
          (q ? (l.title?.toLowerCase().includes(q) || l.streamer?.toLowerCase().includes(q) || l.category?.toLowerCase().includes(q)) : true) &&
          (activeCategory ? l.category === activeCategory : true)
        );

        // Fetch creators from Firestore
        let creators: any[] = [];
        if (q) {
          const userQuery = query(collection(db, 'users'), where('username', '>=', q), limit(10));
          const snapshot = await getDocs(userQuery);
          creators = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        }

        setSearchResults({ lives: filteredLives, creators });
      } catch (error) {
        console.error('Search error:', error);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm, activeCategory, allLives]);

  const isSearched = searchTerm.trim() !== '' || activeCategory !== null;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-12 pb-24">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-4xl font-black tracking-tighter uppercase leading-none">Explore</h1>
        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.2em]">Discover lives, creators and trends</p>
      </div>

      {/* Search Bar */}
      <div className="relative group">
        <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
          <SearchIcon className="w-5 h-5 text-gray-500 group-focus-within:text-neon-purple transition-colors" />
        </div>
        <input 
          type="text" 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search creators, streams, topics..."
          className="w-full bg-white/5 border border-white/10 rounded-2xl py-5 pl-14 pr-14 text-sm focus:outline-none focus:border-neon-purple/50 transition-all backdrop-blur-xl shadow-2xl"
        />
        {searchTerm && (
          <button 
            onClick={() => setSearchTerm('')}
            className="absolute inset-y-0 right-6 flex items-center"
          >
            <X className="w-5 h-5 text-gray-500 hover:text-white transition-colors" />
          </button>
        )}
      </div>

      {/* Categories */}
      <section>
        <div className="flex items-center gap-3 mb-6">
          <Radio className="w-5 h-5 text-neon-purple" />
          <h2 className="text-xl font-black tracking-tight uppercase">Categories</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {CATEGORIES.map((cat, i) => (
            <motion.button 
              key={cat.name}
              initial={{ opacity: 0, y: 10 }} 
              animate={{ opacity: 1, y: 0 }} 
              transition={{ delay: i * 0.05 }}
              onClick={() => setActiveCategory(activeCategory === cat.name ? null : cat.name)}
              className={`relative overflow-hidden rounded-2xl p-4 text-left group cursor-pointer bg-gradient-to-br ${cat.grad} transition-all ${activeCategory === cat.name ? 'ring-2 ring-white scale-105 shadow-[0_0_20px_rgba(255,255,255,0.2)]' : 'hover:opacity-90 hover:scale-102 opacity-60'}`}
            >
              <div className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity bg-white" />
              <span className="text-2xl block mb-2">{cat.emoji}</span>
              <p className="text-white font-black text-[10px] uppercase tracking-widest">{cat.name}</p>
            </motion.button>
          ))}
        </div>
      </section>

      {/* Trending Tags */}
      {!isSearched && (
        <section>
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-5 h-5 text-neon-red" />
            <h2 className="text-xl font-black tracking-tight uppercase">Trending Tags</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {TRENDING_TAGS.map((tag, i) => (
              <motion.button 
                key={tag}
                initial={{ opacity: 0, scale: 0.8 }} 
                animate={{ opacity: 1, scale: 1 }} 
                transition={{ delay: i * 0.04 }}
                onClick={() => setSearchTerm(tag)}
                className="flex items-center gap-2 glass-panel border-white/5 px-5 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest text-gray-400 hover:border-neon-blue/50 hover:text-white transition-all"
              >
                <Hash className="w-3 h-3 text-neon-blue" />
                {tag}
              </motion.button>
            ))}
          </div>
        </section>
      )}

      {/* Results */}
      <AnimatePresence mode="wait">
        {isSearched && (
          <motion.div 
            key="results"
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }} 
            exit={{ opacity: 0, y: -20 }}
            className="space-y-12"
          >
            {/* Creators */}
            {searchResults.creators.length > 0 && (
              <section>
                <div className="flex items-center gap-3 mb-6">
                  <Users className="w-5 h-5 text-neon-blue" />
                  <h2 className="text-xl font-black tracking-tight uppercase">Creators</h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {searchResults.creators.map((user) => (
                    <Link 
                      key={user.id} 
                      to={`/profile/${user.username}`}
                      className="glass-panel p-4 flex items-center gap-4 hover:bg-white/10 transition-all group border-white/5"
                    >
                      <div className="relative">
                        <img src={user.photoURL} alt={user.username} className="w-12 h-12 rounded-full border border-neon-blue/30 object-cover" />
                        {user.isLive && (
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-neon-red rounded-full border-2 border-black animate-soft-pulse" />
                        )}
                      </div>
                      <div>
                        <p className="font-black group-hover:neon-text-blue transition-colors">@{user.username}</p>
                        <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">{user.followersCount} Followers</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* Lives */}
            <section>
              <div className="flex items-center gap-3 mb-6">
                <Radio className="w-5 h-5 text-neon-red" />
                <h2 className="text-xl font-black tracking-tight uppercase">Lives Found</h2>
              </div>
              {searchResults.lives.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {searchResults.lives.map((live) => (
                    <LiveCard 
                      key={live.id} 
                      live={live} 
                      onClick={() => setActiveStream(live)}
                    />
                  ))}
                </div>
              ) : (
                <div className="py-20 text-center glass-panel border-white/5">
                  <p className="text-gray-500 font-black uppercase tracking-[0.2em]">No lives found in this category</p>
                </div>
              )}
            </section>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Live Player Modal */}
      <AnimatePresence>
        {activeStream && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-0 md:p-10"
          >
            <div className="w-full h-full max-w-6xl aspect-video md:rounded-[2.5rem] overflow-hidden border border-white/10 shadow-[0_0_100px_rgba(176,38,255,0.2)]">
              <LivePlayer 
                streamId={activeStream.id}
                streamerName={activeStream.streamer}
                streamerPhoto={activeStream.photo}
                viewerCount={activeStream.viewers}
                onClose={() => setActiveStream(null)}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
