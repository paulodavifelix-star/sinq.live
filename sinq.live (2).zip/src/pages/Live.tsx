import React, { useState, useEffect } from 'react';
import { LivePlayer } from '../components/LivePlayer';
import { useAppStore } from '../store/appStore';
import { useNavigate } from 'react-router-dom';

export const Live: React.FC = () => {
  const navigate = useNavigate();
  const { clearChat } = useAppStore();

  useEffect(() => {
    // Clear chat when entering a new live
    clearChat();
  }, [clearChat]);

  return (
    <div className="h-full w-full">
      <LivePlayer
        streamId="live_001"
        streamerName="dev_davi"
        streamerPhoto="https://picsum.photos/seed/davi/200"
        viewerCount={1240}
        onClose={() => navigate('/')}
      />
    </div>
  );
};
