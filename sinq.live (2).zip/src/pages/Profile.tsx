import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { User, Grid, Heart, Settings, LogOut, Radio, MessageSquare } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { db, collection, query, where, getDocs, handleFirestoreError, OperationType } from '../services/firebase';
import { useAppStore } from '../store/appStore';
import { NeonButton } from '../components/NeonButton';
import { cn } from '../lib/utils';

export const Profile: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const userProfile = useAppStore(state => state.userProfile);
  const [profileData, setProfileData] = useState<any>(null);
  const [profilePosts, setProfilePosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const isOwnProfile = userProfile?.username === username || user?.uid === username;

  useEffect(() => {
    const fetchProfile = async () => {
      if (!username) return;
      setLoading(true);
      try {
        // Fetch user data
        let q = query(collection(db, 'users'), where('username', '==', username));
        let snapshot = await getDocs(q);
        
        if (snapshot.empty) {
          q = query(collection(db, 'users'), where('uid', '==', username));
          snapshot = await getDocs(q);
        }

        if (!snapshot.empty) {
          const data = snapshot.docs[0].data();
          setProfileData({ id: snapshot.docs[0].id, ...data });
          
          // Fetch posts
          const postsQ = query(collection(db, 'posts'), where('username', '==', data.username));
          const postsSnapshot = await getDocs(postsQ);
          setProfilePosts(postsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'users');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [username]);

  const handleLogout = async () => {
    await logout();
    navigate('/auth');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-2 border-neon-purple border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!profileData) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center">
        <User className="w-16 h-16 text-gray-700 mb-4" />
        <h2 className="text-xl font-bold mb-2">User not found</h2>
        <p className="text-gray-500 mb-6">The profile you are looking for doesn't exist on sinq.live.</p>
        <NeonButton onClick={() => navigate('/')}>Go Home</NeonButton>
      </div>
    );
  }

  return (
    <div className="min-h-full bg-black/20 pb-20">
      {/* Profile Header */}
      <div className="relative h-48 bg-gradient-to-b from-neon-purple/20 to-transparent">
        <div className="absolute -bottom-16 left-6 flex items-end gap-6">
          <div className="relative">
            <img 
              src={profileData.photoURL || `https://picsum.photos/seed/${profileData.username}/200`} 
              alt={profileData.displayName} 
              className="w-32 h-32 rounded-3xl object-cover border-4 border-black shadow-[0_0_20px_rgba(176,38,255,0.3)]"
            />
            {profileData.isLive && (
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-neon-red px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border-2 border-black">
                Live
              </div>
            )}
          </div>
          <div className="mb-2">
            <h1 className="text-3xl font-black tracking-tighter leading-none mb-1">{profileData.displayName}</h1>
            <p className="text-neon-purple font-bold text-sm">@{profileData.username}</p>
          </div>
        </div>
      </div>

      <div className="mt-20 px-6 space-y-8">
        {/* Stats & Actions */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex gap-8">
            <div className="flex flex-col">
              <span className="text-xl font-black">{profileData.followersCount?.toLocaleString() || 0}</span>
              <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Followers</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black">{profileData.followingCount?.toLocaleString() || 0}</span>
              <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Following</span>
            </div>
          </div>

          <div className="flex gap-3">
            {isOwnProfile ? (
              <>
                <NeonButton variant="purple" size="sm">Edit Profile</NeonButton>
                <button 
                  onClick={handleLogout}
                  className="p-2.5 rounded-full bg-white/5 border border-white/10 text-gray-400 hover:text-neon-red hover:bg-neon-red/10 transition-all"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </>
            ) : (
              <>
                <NeonButton variant="purple" size="sm">Follow</NeonButton>
                <button className="p-2.5 rounded-full bg-white/5 border border-white/10 text-gray-400 hover:text-neon-blue hover:bg-neon-blue/10 transition-all">
                  <MessageSquare className="w-5 h-5" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Bio */}
        <div className="glass-panel p-6">
          <h3 className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-2">About</h3>
          <p className="text-gray-200 leading-relaxed">{profileData.bio || 'No bio yet.'}</p>
        </div>

        {/* Content Tabs */}
        <div className="space-y-6">
          <div className="flex border-b border-white/5">
            <button className="px-6 py-3 border-b-2 border-neon-purple text-neon-purple font-bold text-sm flex items-center gap-2">
              <Grid className="w-4 h-4" />
              Posts
            </button>
            <button className="px-6 py-3 text-gray-500 font-bold text-sm flex items-center gap-2 hover:text-gray-300">
              <Radio className="w-4 h-4" />
              Lives
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {profilePosts.length > 0 ? (
              profilePosts.map((post) => (
                <div key={post.id} className="glass-panel p-4 group cursor-pointer">
                  {post.image && (
                    <div className="aspect-square rounded-xl overflow-hidden mb-4">
                      <img src={post.image} alt="Post" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                    </div>
                  )}
                  <p className="text-sm text-gray-200 line-clamp-2 mb-4">{post.content}</p>
                  <div className="flex items-center gap-4 text-[10px] text-gray-500 font-bold uppercase tracking-widest">
                    <span className="flex items-center gap-1"><Heart className="w-3 h-3" /> {post.likesCount}</span>
                    <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" /> {post.commentsCount}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full py-20 text-center glass-panel">
                <p className="text-gray-500 font-bold uppercase tracking-widest">No posts yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
