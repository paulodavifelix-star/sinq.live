import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn, UserPlus, ShieldCheck, AlertCircle, Loader2, Radio } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { NeonButton } from '../components/NeonButton';
import { signInWithPopup, auth, googleProvider } from '../services/firebase';

export const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const { login } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleLogin = async (retries = 1) => {
    setLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
      navigate('/');
    } catch (err: any) {
      if (err.code === 'auth/too-many-requests') {
        setError('Too many attempts. Please try again in a few minutes.');
      } else if (err.code === 'auth/network-request-failed' && retries > 0) {
        // Retry once on network failure
        await handleGoogleLogin(retries - 1);
      } else {
        setError(err.message || 'Failed to login with Google');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAnonymousLogin = async (retries = 1) => {
    setLoading(true);
    setError(null);
    try {
      await login();
      navigate('/');
    } catch (err: any) {
      if (err.code === 'auth/too-many-requests') {
        setError('Too many attempts. Please try again in a few minutes.');
      } else if (err.code === 'auth/network-request-failed' && retries > 0) {
        // Retry once on network failure
        await handleAnonymousLogin(retries - 1);
      } else {
        setError(err.message || 'Failed to login anonymously');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-full flex items-center justify-center p-6">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-neon-purple to-neon-pink rounded-2xl shadow-[0_0_30px_rgba(176,38,255,0.4)] mb-4">
            <Radio className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-black tracking-tighter neon-text-purple">sinq.live</h1>
          <p className="text-gray-400 font-medium">The future of interactive streaming</p>
        </div>

        <div className="glass-panel p-8 space-y-6">
          <div className="flex p-1 bg-white/5 rounded-full mb-6">
            <button 
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${isLogin ? 'bg-neon-purple text-white shadow-[0_0_15px_rgba(176,38,255,0.3)]' : 'text-gray-500 hover:text-gray-300'}`}
            >
              Entrar
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${!isLogin ? 'bg-neon-purple text-white shadow-[0_0_15px_rgba(176,38,255,0.3)]' : 'text-gray-500 hover:text-gray-300'}`}
            >
              Criar Conta
            </button>
          </div>

          {error && (
            <div className="bg-neon-red/10 border border-neon-red/20 p-4 rounded-xl flex items-center gap-3 text-neon-red text-xs font-bold">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          <div className="space-y-4">
            <NeonButton 
              onClick={handleGoogleLogin} 
              className="w-full flex items-center justify-center gap-3 py-4"
              disabled={loading}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <LogIn className="w-5 h-5" />}
              Continuar com Google
            </NeonButton>

            <button 
              onClick={handleAnonymousLogin}
              disabled={loading}
              className="w-full py-4 rounded-full border border-white/10 font-bold text-sm hover:bg-white/5 transition-all text-gray-300"
            >
              Continuar como Convidado
            </button>
          </div>

          <div className="pt-4 text-center">
            <div className="flex items-center justify-center gap-2 text-[10px] text-gray-500 uppercase font-black tracking-widest">
              <ShieldCheck className="w-3 h-3" />
              Autenticação Neon Segura
            </div>
          </div>
        </div>

        <p className="text-center text-[10px] text-gray-600 uppercase font-bold tracking-[0.2em] px-8">
          Ao continuar, você concorda com os Termos de Serviço e a Política de Privacidade do sinq.live.
        </p>
      </div>
    </div>
  );
};
