import { useState, useEffect } from 'react';
import { TrendingUp, Users, Eye, DollarSign, Radio, Award, Heart, BarChart2 } from 'lucide-react';
// import { base44 } from '@/api/base44Client';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { motion } from 'framer-motion';

const MOCK_VIEWS = [
  { day: 'Seg', views: 1200, donations: 45 },
  { day: 'Ter', views: 2100, donations: 80 },
  { day: 'Qua', views: 900, donations: 30 },
  { day: 'Qui', views: 3400, donations: 120 },
  { day: 'Sex', views: 4800, donations: 200 },
  { day: 'Sab', views: 6200, donations: 340 },
  { day: 'Dom', views: 5100, donations: 280 },
];

export default function Dashboard() {
  const [profile, setProfile] = useState<any>(null);
  const [lives, setLives] = useState<any[]>([]);
  const [donations, setDonations] = useState<any[]>([]);
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false); // Changed to false for now

  useEffect(() => { /* load(); */ }, []);

  const load = async () => {
    // const user = await base44.auth.me();
    // const [profiles, livesData, donationsData, postsData] = await Promise.all([
    //   base44.entities.UserProfile.filter({ created_by: user.email }),
    //   base44.entities.Live.filter({ host_user_id: user.id }, '-created_date', 10),
    //   base44.entities.Donation.filter({ to_username: user.email.split('@')[0] }, '-created_date', 20),
    //   base44.entities.Post.filter({ created_by: user.email }, '-created_date', 10),
    // ]);
    // setProfile(profiles[0]);
    // setLives(livesData);
    // setDonations(donationsData);
    // setPosts(postsData);
    // setLoading(false);
  };

  const totalDonations = donations.reduce((sum, d) => sum + (d.amount || 0), 0);
  const totalLikes = posts.reduce((sum, p) => sum + (p.likes_count || 0), 0);

  const stats = [
    { label: 'Seguidores', value: profile?.followers_count || 0, icon: Users, color: 'text-purple-400', bg: 'from-purple-600/20 to-purple-900/10' },
    { label: 'Visualizações', value: profile?.total_views || 0, icon: Eye, color: 'text-blue-400', bg: 'from-blue-600/20 to-blue-900/10' },
    { label: 'Doações (R$)', value: totalDonations.toFixed(2), icon: DollarSign, color: 'text-green-400', bg: 'from-green-600/20 to-green-900/10' },
    { label: 'Curtidas', value: totalLikes, icon: Heart, color: 'text-red-400', bg: 'from-red-600/20 to-red-900/10' },
  ];

  return (
    <div className="min-h-screen px-4 md:px-8 py-6 max-w-6xl mx-auto">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 rounded-xl gradient-purple glow-purple">
          <BarChart2 className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="font-orbitron font-bold text-2xl text-white">Dashboard do Criador</h1>
          <p className="text-purple-400/60 text-sm">Seus dados e métricas de engajamento</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map(({ label, value, icon: Icon, color, bg }, i) => (
          <motion.div key={label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
            className={`glass border border-purple-900/30 rounded-2xl p-5 bg-gradient-to-br ${bg}`}>
            <Icon className={`w-6 h-6 ${color} mb-2`} />
            <p className="text-white font-bold text-2xl font-orbitron">{typeof value === 'number' ? value.toLocaleString() : value}</p>
            <p className="text-purple-400/60 text-xs mt-1">{label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Views chart */}
        <div className="lg:col-span-2 glass border border-purple-900/30 rounded-2xl p-5">
          <h3 className="text-white font-bold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-400" /> Visualizações (7 dias)
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={MOCK_VIEWS}>
              <defs>
                <linearGradient id="viewGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="day" stroke="#6b21a8" tick={{ fill: '#a855f7', fontSize: 12 }} />
              <YAxis stroke="#6b21a8" tick={{ fill: '#a855f7', fontSize: 12 }} />
              <Tooltip contentStyle={{ background: '#1a0a2e', border: '1px solid #a855f7', borderRadius: 12, color: 'white' }} />
              <Area type="monotone" dataKey="views" stroke="#a855f7" fill="url(#viewGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Donations */}
        <div className="glass border border-purple-900/30 rounded-2xl p-5">
          <h3 className="text-white font-bold mb-4 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-green-400" /> Doações Recentes
          </h3>
          <div className="space-y-3 max-h-48 overflow-y-auto">
            {donations.length === 0 ? (
              <p className="text-purple-400/40 text-sm text-center py-6">Nenhuma doação ainda</p>
            ) : donations.slice(0, 8).map((d) => (
              <div key={d.id} className="flex items-center justify-between">
                <div>
                  <p className="text-white text-xs font-semibold">{d.from_display_name || d.from_username}</p>
                  {d.message && <p className="text-purple-400/50 text-xs truncate max-w-32">{d.message}</p>}
                </div>
                <span className="text-green-400 font-bold text-sm">
                  {d.type === 'pix' ? `R$${d.amount}` : d.gift_type || '🎁'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Donations bar chart */}
      <div className="glass border border-purple-900/30 rounded-2xl p-5 mb-6">
        <h3 className="text-white font-bold mb-4 flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-green-400" /> Receita de Doações (7 dias)
        </h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={MOCK_VIEWS}>
            <XAxis dataKey="day" stroke="#6b21a8" tick={{ fill: '#a855f7', fontSize: 12 }} />
            <YAxis stroke="#6b21a8" tick={{ fill: '#a855f7', fontSize: 12 }} />
            <Tooltip contentStyle={{ background: '#1a0a2e', border: '1px solid #10b981', borderRadius: 12, color: 'white' }} />
            <Bar dataKey="donations" fill="#10b981" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Lives history */}
      <div className="glass border border-purple-900/30 rounded-2xl p-5">
        <h3 className="text-white font-bold mb-4 flex items-center gap-2">
          <Radio className="w-5 h-5 text-red-400" /> Histórico de Lives
        </h3>
        {lives.length === 0 ? (
          <p className="text-purple-400/40 text-sm text-center py-6">Nenhuma live realizada</p>
        ) : (
          <div className="space-y-3">
            {lives.map((live) => (
              <div key={live.id} className="flex items-center justify-between py-2 border-b border-purple-900/20">
                <div>
                  <p className="text-white text-sm font-semibold">{live.title}</p>
                  <p className="text-purple-400/50 text-xs">{live.category}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 text-blue-400 text-xs"><Eye className="w-3 h-3" />{live.viewer_count || 0}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${live.is_active ? 'bg-red-500/20 text-red-400' : 'bg-purple-900/30 text-purple-400'}`}>
                    {live.is_active ? '● Ao vivo' : 'Encerrada'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
