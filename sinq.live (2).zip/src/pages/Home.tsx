import React, { useState, useEffect } from 'react';
import { collection, db, onSnapshot, query, orderBy, limit, handleFirestoreError, OperationType } from '../services/firebase';
import { useAppStore } from '../store/appStore';
import { Radio, Users, Heart, MessageCircle, Play, TrendingUp, Sparkles, Clock, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { NeonButton } from '../components/NeonButton';
import { Link } from 'react-router-dom';
import { LivePlayer } from '../components/LivePlayer';
import { LiveCard } from '../components/LiveCard';
import { formatRelativeTime } from '../lib/utils';

const BOTS_AUTO = [
  {u: 'neon_rider', m: 'This stream is fire! 🔥', t: 'm'},
  {u: 'cyber_queen', m: 'Love the vibes here ✨', t: 'f'},
  {u: 'pixel_pioneer', m: 'How do you do that?? 😲', t: 'm'},
  {u: 'glitch_girl', m: 'Sinq.live is the best! 💜', t: 'f'},
];

const PostSkeleton = () => (
  <div className="glass-panel p-6 space-y-4 animate-pulse">
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 rounded-full bg-white/10" />
      <div className="space-y-2">
        <div className="w-24 h-3 bg-white/10 rounded" />
        <div className="w-16 h-2 bg-white/10 rounded" />
      </div>
    </div>
    <div className="space-y-2">
      <div className="w-full h-4 bg-white/10 rounded" />
      <div className="w-3/4 h-4 bg-white/10 rounded" />
    </div>
    <div className="w-full h-40 bg-white/10 rounded-xl" />
  </div>
);

export const Home: React.FC = () => {
  const [lives, setLives] = useState<any[]>([]);
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeStream, setActiveStream] = useState<any>(null);
  const { addChatMessage, setLiveViews, liveViews } = useAppStore();

  useEffect(() => {
    // Simulate fetching lives
    const mockLives = [
      { id: 'l1', title: 'Late Night Coding', streamer: 'dev_davi', viewers: 1240, thumbnail: 'https://picsum.photos/seed/code/600/800', category: 'Coding', photo: 'https://picsum.photos/seed/p1/100' },
      { id: 'l2', title: 'Neon Art Session', streamer: 'art_vibe', viewers: 850, thumbnail: 'https://picsum.photos/seed/art/600/800', category: 'Creative', photo: 'https://picsum.photos/seed/p2/100' },
      { id: 'l3', title: 'Gaming with Subs', streamer: 'pro_gamer', viewers: 3200, thumbnail: 'https://picsum.photos/seed/game/600/800', category: 'Gaming', photo: 'https://picsum.photos/seed/p3/100' },
      { id: 'l4', title: 'Cyberpunk Beats', streamer: 'dj_neon', viewers: 1500, thumbnail: 'https://picsum.photos/seed/music/600/800', category: 'Music', photo: 'https://picsum.photos/seed/p4/100' },
    ];
    setLives(mockLives);

    // Fetch posts from Firestore
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(12));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const postData = snapshot.docs.map(doc => ({ 
        id: doc.id, 
        ...doc.data(),
        timeAgo: formatRelativeTime(doc.data().createdAt)
      }));
      setPosts(postData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'posts');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Auto-Pilot Bot Logic
  useEffect(() => {
    const interval = setInterval(() => {
      const bot = BOTS_AUTO[Math.floor(Math.random() * BOTS_AUTO.length)];
      addChatMessage(bot);
      setLiveViews(Math.floor(Math.random() * 1000) + 500);
    }, 4000);
    return () => clearInterval(interval);
  }, [addChatMessage, setLiveViews]);

  return (
    <div className="p-6 space-y-12 max-w-7xl mx-auto pb-24 font-sans">
      {/* Hero Section */}
      <section className="relative h-[60vh] sm:h-[450px] rounded-[2rem] sm:rounded-[2.5rem] overflow-hidden group">
        <motion.div 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.5 }}
          className="absolute inset-0"
        >
          <img 
            src="https://picsum.photos/seed/cyberpunk/1200/800" 
            alt="Featured" 
            className="w-full h-full object-cover"
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-black via-black/60 to-transparent flex flex-col justify-end sm:justify-center p-6 sm:p-12">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 mb-4 sm:mb-6"
          >
            <div className="bg-neon-red px-3 py-1 sm:px-4 sm:py-1.5 rounded-full text-[9px] sm:text-[10px] font-black uppercase tracking-[0.2em] shadow-[0_0_20px_rgba(255,0,85,0.4)] animate-soft-pulse">
              Ao Vivo em Destaque
            </div>
            <div className="flex items-center gap-1 text-neon-blue text-[9px] sm:text-[10px] font-black uppercase tracking-widest">
              <Sparkles className="w-3 h-3" />
              Em Alta
            </div>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-4xl sm:text-6xl font-black mb-4 sm:mb-6 tracking-tighter leading-[0.9]"
          >
            O FUTURO DO <br />
            <span className="gradient-text">STREAMING</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-gray-300 max-w-lg mb-6 sm:mb-10 text-sm sm:text-lg font-medium leading-relaxed"
          >
            Experimente a plataforma de streaming ao vivo mais interativa. Conecte-se com criadores em um universo movido a neon.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex gap-3 sm:gap-4"
          >
            <NeonButton size="lg" className="px-6 sm:px-10 text-sm sm:text-base">Começar a Assistir</NeonButton>
            <button className="px-6 sm:px-10 py-3 sm:py-4 rounded-full border border-white/20 font-black uppercase tracking-widest text-[10px] sm:text-xs hover:bg-white/10 hover:border-white/40 transition-all backdrop-blur-md">
              Explorar
            </button>
          </motion.div>
        </div>
      </section>

      {/* Live Now Grid - Bento Style */}
      <section>
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-neon-red/10 rounded-2xl">
              <Radio className="w-6 h-6 text-neon-red" />
            </div>
            <div>
              <h2 className="text-3xl font-black tracking-tight uppercase leading-none">Ao Vivo Agora</h2>
              <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">Interações em tempo real</p>
            </div>
          </div>
          <Link to="/search" className="group flex items-center gap-2 text-neon-purple text-xs font-black uppercase tracking-widest hover:neon-text-purple transition-all">
            Ver Todos <TrendingUp className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {lives.map((live) => (
            <LiveCard 
              key={live.id} 
              live={live} 
              onClick={() => setActiveStream(live)} 
            />
          ))}
        </div>
      </section>

      {/* Community Posts */}
      <section>
        <div className="flex items-center gap-4 mb-8">
          <div className="p-3 bg-neon-blue/10 rounded-2xl">
            <MessageCircle className="w-6 h-6 text-neon-blue" />
          </div>
          <div>
            <h2 className="text-3xl font-black tracking-tight uppercase leading-none">Comunidade</h2>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">O que há de novo no mundo neon</p>
          </div>
        </div>

        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
          {loading ? (
            [...Array(6)].map((_, i) => <PostSkeleton key={i} />)
          ) : (
            <AnimatePresence>
              {posts.map((post, idx) => (
                <motion.div 
                  key={post.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="glass-panel p-6 break-inside-avoid hover:border-neon-blue/30 transition-all group"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img src={post.userPhoto} alt={post.username} className="w-10 h-10 rounded-full border border-neon-blue/30 object-cover" />
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-neon-blue rounded-full border-2 border-black flex items-center justify-center">
                          <Sparkles className="w-2 h-2 text-black" />
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-black group-hover:neon-text-blue transition-colors">@{post.username}</p>
                        <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest">{post.timeAgo}</p>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-gray-200 text-sm leading-relaxed mb-4 font-medium">{post.content}</p>
                  
                  {post.image && (
                    <div className="relative rounded-2xl overflow-hidden mb-4 border border-white/5 aspect-video">
                      <img src={post.image} alt="Post" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  )}
                  
                  <div className="flex items-center gap-6 pt-2">
                    <button className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-neon-red transition-all">
                      <Heart className="w-4 h-4" />
                      {post.likesCount}
                    </button>
                    <button className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-neon-blue transition-all">
                      <MessageCircle className="w-4 h-4" />
                      {post.commentsCount}
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
        </div>
      </section>

      {/* Live Player Modal */}
      <AnimatePresence>
        {activeStream && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-0 md:p-10"
          >
            <div className="w-full h-full max-w-6xl aspect-video md:rounded-[2.5rem] overflow-hidden border border-white/10 shadow-[0_0_100px_rgba(176,38,255,0.2)]">
              <LivePlayer 
                streamId={activeStream.id}
                streamerName={activeStream.streamer}
                streamerPhoto={activeStream.photo}
                viewerCount={activeStream.viewers}
                onClose={() => setActiveStream(null)}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
