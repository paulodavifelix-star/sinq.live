import React, { Suspense, lazy, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import LoadingScreen from './components/LoadingScreen';
import ErrorBoundary from './components/ErrorBoundary';
import { useAuth } from './hooks/useAuth';

// Lazy load pages
const Home = lazy(() => import('./pages/Home').then(module => ({ default: module.Home })));
const Profile = lazy(() => import('./pages/Profile').then(module => ({ default: module.Profile })));
const Upload = lazy(() => import('./pages/Upload').then(module => ({ default: module.Upload })));
const Search = lazy(() => import('./pages/Search').then(module => ({ default: module.Search })));
const Auth = lazy(() => import('./pages/Auth').then(module => ({ default: module.Auth })));
const Live = lazy(() => import('./pages/Live').then(module => ({ default: module.Live })));

const App: React.FC = () => {
  const { user, loading, login } = useAuth();
  const [attemptedLogin, setAttemptedLogin] = React.useState(() => 
    sessionStorage.getItem('attemptedLogin') === 'true'
  );

  useEffect(() => {
    if (!loading && !user && !attemptedLogin) {
      setAttemptedLogin(true);
      sessionStorage.setItem('attemptedLogin', 'true');
      login().catch(err => console.error('Auto-login failed:', err));
    }
  }, [user, loading, login, attemptedLogin]);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <ErrorBoundary>
      <Router>
        <Layout>
          <Suspense fallback={<LoadingScreen />}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/search" element={<Search />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="/live" element={<Live />} />
              <Route 
                path="/profile/:username" 
                element={<Profile />} 
              />
              <Route 
                path="/upload" 
                element={user ? <Upload /> : <Navigate to="/auth" />} 
              />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Suspense>
        </Layout>
      </Router>
    </ErrorBoundary>
  );
};

export default App;
